

'use strict';

/* eslint-disable no-unused-vars */


const functions = require('@google-cloud/functions-framework');

const escapeHtml = require('escape-html');
// Imports the Google Cloud client library
//const {Storage} = require('@google-cloud/storage');

// [START functions_helloworld_pubsub]
/**
 * Background Cloud Function to be triggered by Pub/Sub.
 * This function is exported by index.js, and executed when
 * the trigger topic receives a message.
 *
 * @param {object} message The Pub/Sub message.
 * @param {object} context The event metadata.
 */
exports.helloPubSub = (message, context) => {
  const name = message.data
    ? Buffer.from(message.data, 'base64').toString()
    : 'World';

  console.log(`Hello, ${name}!`);
};
// [END functions_helloworld_pubsub]

// [START functions_helloworld_storage]
/**
 * Generic background Cloud Function to be triggered by Cloud Storage.
 * This sample works for all Cloud Storage CRUD operations.
 *
 * @param {object} file The Cloud Storage file metadata.
 * @param {object} context The event metadata.
 */
 // Creates a client

  
exports.helloGCS = (file, context) => {
  console.log(`  Function Start : `);

  console.log(`  Event: ${context.eventId}`);
  console.log(`  Event Type: ${context.eventType}`);
  console.log(`  Bucket: ${file.bucket}`);
  console.log(`  File: ${file.name}`);
  console.log(`  Metageneration: ${file.metageneration}`);
  console.log(`  Created: ${file.timeCreated}`);
  console.log(`  Updated: ${file.updated}`);
  console.log(`  Data: ${file.data}`);
  console.log(`  Object: ${file.Object}`);
  console.log(`  Body: ${file.body}`);
  console.log(`  String: ${file.toString}`);

 // const storage = new Storage();
 // my_obj = storage.bucket(`${file.bucket}`).file(`${file.name}`).download();
 // console.log(my_obj);

  console.log(`  Function End : `);
};
// [END functions_helloworld_storage]

